list1=[2]
for i in list1:
    print(i)
